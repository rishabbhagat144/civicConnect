from flask import Flask, render_template, request, redirect, url_for, abort, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import cloudinary
import cloudinary.uploader
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///complaints.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

cloudinary.config(
    cloud_name=os.getenv('CLOUDINARY_CLOUD_NAME', 'your_cloud_name'),
    api_key=os.getenv('CLOUDINARY_API_KEY', 'your_api_key'),
    api_secret=os.getenv('CLOUDINARY_API_SECRET', 'your_api_secret')
)

class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    lat = db.Column(db.Float)
    lon = db.Column(db.Float)
    image_url = db.Column(db.String(200))
    status = db.Column(db.String(20), default='Submitted')
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit')
def submit_complaint():
    return render_template('submit.html')

@app.route('/submit', methods=['POST'])
def handle_complaint():
    try:
        title = request.form.get('title')
        description = request.form.get('description')
        location = request.form.get('location')
        lat = request.form.get('lat', type=float)
        lon = request.form.get('lon', type=float)

        if not title or not description or not location:
            flash("Please fill in all required fields.", "error")
            return redirect(url_for('submit_complaint'))

        image_url = None
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename:
                try:
                    upload_result = cloudinary.uploader.upload(file)
                    image_url = upload_result.get('secure_url')
                except Exception as img_err:
                    print("Image upload error:", img_err)
                    # Continue without image if upload fails

        new_complaint = Complaint(
            title=title,
            description=description,
            location=location,
            lat=lat,
            lon=lon,
            image_url=image_url
        )
        db.session.add(new_complaint)
        db.session.commit()
        flash("Complaint submitted successfully!", "success")
        return redirect(url_for('view_complaints'))

    except Exception as e:
        print("Error submitting complaint:", e)
        db.session.rollback()  # Roll back the session in case of database errors
        flash("Something went wrong while submitting your complaint. Please try again.", "error")
        return redirect(url_for('submit_complaint'))

@app.route('/complaints')
def view_complaints():
    complaints = Complaint.query.order_by(Complaint.timestamp.desc()).all()
    return render_template('complaints.html', complaints=complaints)

@app.route('/map')
def map_view():
    complaints = Complaint.query.all()
    return render_template('map.html', complaints=complaints)

@app.route('/admin')
def admin_panel():
    complaints = Complaint.query.all()
    return render_template('admin.html', complaints=complaints)

@app.route('/update/<int:id>', methods=['POST'])
def update_status(id):
    complaint = Complaint.query.get(id)
    if not complaint:
        flash("Complaint not found.", "error")
        return redirect(url_for('admin_panel'))

    new_status = request.form.get('status')
    if new_status not in ['Submitted', 'In Review', 'In Progress', 'Resolved']:
        flash("Invalid status.", "error")
        return redirect(url_for('admin_panel'))

    complaint.status = new_status
    db.session.commit()
    flash(f"Status updated to {new_status}.", "success")
    return redirect(url_for('admin_panel'))

@app.errorhandler(404)
def not_found_error(e):
    return render_template("error.html", code=404, message="Page not found."), 404

@app.errorhandler(500)
def internal_error(e):
    db.session.rollback()
    return render_template("error.html", code=500, message="Internal server error."), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
