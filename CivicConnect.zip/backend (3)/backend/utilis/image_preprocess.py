from PIL import Image, UnidentifiedImageError
import numpy as np
import os

def preprocess_image(image_path, target_size=(224, 224)):
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image path does not exist: {image_path}")

    try:
        image = Image.open(image_path)
        image = image.convert('RGB')
        image = image.resize(target_size)
        image_array = np.array(image) / 255.0
        image_array = np.expand_dims(image_array, axis=0)
        return image_array
    except UnidentifiedImageError:
        raise ValueError(f"Could not identify image file: {image_path}")
